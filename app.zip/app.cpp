#include <stdio.h>

int main () 
{
	printf("Hello World! V1\n");
	return 0;
}
